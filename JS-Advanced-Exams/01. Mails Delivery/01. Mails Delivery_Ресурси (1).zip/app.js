function solve() {

}
solve()