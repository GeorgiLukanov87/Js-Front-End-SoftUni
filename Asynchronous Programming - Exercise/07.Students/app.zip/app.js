function attachEvents() {
  const urlStudents = "http://localhost:3030/jsonstore/collections/students";
  const firstName = document.querySelector("input[name='firstName']");
  const lastName = document.querySelector("input[name='lastName']");
  const facNumber = document.querySelector("input[name='facultyNumber']");
  const grade = document.querySelector("input[name='grade']");
  const table = document.getElementById("results").tBodies[0];
  presentData();
  const submitBtn = document.getElementById("submit");
 
  submitBtn.addEventListener("click", submiting);
 
  function presentData() {
    fetch(urlStudents)
      .then((response) => response.json())
      .then((data) => {
        for (dataRow in data) {
          let studentFirstName = data[dataRow]["firstName"];
          let studentLastName = data[dataRow]["lastName"];
          let studentFacNumber = data[dataRow]["facultyNumber"];
          let studentGrade = data[dataRow]["grade"];
 
          let row = document.createElement("tr");
 
          let tdFirstname = document.createElement("td");
          tdFirstname.textContent = studentFirstName;
 
          let tdLastName = document.createElement("td");
          tdLastName.textContent = studentLastName;
 
          let tdFacNumber = document.createElement("td");
          tdFacNumber.textContent = studentFacNumber;
 
          let tdGrade = document.createElement("td");
          tdGrade.textContent = studentGrade;
 
          row.appendChild(tdFirstname);
          row.appendChild(tdLastName);
          row.appendChild(tdFacNumber);
          row.appendChild(tdGrade);
 
          table.appendChild(row);
        }
      });
  }
 
  function submiting() {
    if (firstName.value && lastName.value && facNumber.value && grade.value) {
      let theName = firstName.value;
      let secondName = lastName.value;
      let number = facNumber.value;
      let theGrade = grade.value;
 
      
      firstName.value = "";
      lastName.value = "";
      facNumber.value = "";
      grade.value = "";
 
      data = {
        firstName: theName,
        lastName: secondName,
        facultyNumber: number,
        grade: theGrade,
      };
 
      fetch(urlStudents, {
        method: "post",
        headers: {
          "Content-type": "applicaiton/json",
        },
        body: JSON.stringify(data),
      });
      document.location.reload()

 
      
    }
 
  }

}
 
attachEvents();


// function attachEvents() {
//   const url = 'http://localhost:3030/jsonstore/collections/students';
//   loadStudentsInfo();

//   const submitBtn = document.getElementById('submit');
//   const tableResults = document.querySelector('#results tbody');
//   const inputs = document.querySelector('#form .inputs');

//   submitBtn.addEventListener('click', addNewStudent);

//   function addNewStudent() {
//     let inputFristName = inputs.children[0].value;
//     let inputLastName = inputs.children[1].value;
//     let inputFacNumber = inputs.children[2].value;
//     let inputGrade = inputs.children[3].value;
//     if (inputFristName === '' || inputLastName === '' || inputFacNumber === '' || inputGrade === '') {
//       return;
//     }
//     fetch(url, {
//       method: 'POST',
//       headers: {
//         'content-type': 'application/json'
//       },
//       body: JSON.stringify({
//         'firstName': inputFristName,
//         'lastName': inputLastName,
//         'facultyNumber': inputFacNumber,
//         'grade': inputGrade
//       })
//     })
//       .then(res => res.json())

//     document.location.reload();
//   }


//   function loadStudentsInfo() {
//     fetch(url)
//       .then(res => res.json())
//       .then(data => {
//         for (obj in data) {
//           let firstName = data[obj]['firstName']
//           let lastName = data[obj]['lastName']
//           let facultyNumber = data[obj]['facultyNumber']
//           let grade = data[obj]['grade']

//           let newTr = document.createElement('tr');

//           let firstNameTd = document.createElement('td');
//           firstNameTd.textContent = firstName;
//           let lastNameTd = document.createElement('td');
//           lastNameTd.textContent = lastName;
//           let facultyNumberTd = document.createElement('td');
//           facultyNumberTd.textContent = facultyNumber;
//           let gradeTd = document.createElement('td');
//           gradeTd.textContent = grade;

//           newTr.appendChild(firstNameTd);
//           newTr.appendChild(lastNameTd);
//           newTr.appendChild(facultyNumberTd);
//           newTr.appendChild(gradeTd);

//           tableResults.appendChild(newTr);
//         }
//       })
//   }

// }

// attachEvents();